package com.axter.kelompok_6_x

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Random
import java.util.concurrent.TimeUnit

class ProsesPembayaran : AppCompatActivity() {

    private lateinit var countDownTimer: CountDownTimer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.proses_bayar)

        val totalHarga: Int = intent.getIntExtra("EXTRA_TOTAL_HARGA", 0)

        val rincianHarga: TextView = findViewById(R.id.totalHarga)
        rincianHarga.text = "Rp.$totalHarga"

        val timer: TextView = findViewById(R.id.waktu)
        startCountDownTimer(timer)

        val kode: TextView = findViewById(R.id.kodeUnik)
        kode.text = generateRandomCode(12)

        val berhasilButton: Button = findViewById(R.id.selesai_bayar)

        // Tambahkan listener untuk menangani klik tombol "Bayar"
        berhasilButton.setOnClickListener(View.OnClickListener {
            // Buat Intent untuk membuka aktivitas pembayaran
            val intent = Intent(this, BerhasilBayarActivity::class.java)

            // Mulai aktivitas pembayaran
            startActivity(intent)
        })
    }

    private fun startCountDownTimer(timerTextView: TextView) {
        countDownTimer = object : CountDownTimer(
            TimeUnit.HOURS.toMillis(24), // Waktu total hitung mundur (24 jam)
            1000 // Interval update setiap detik
        ) {
            override fun onTick(millisUntilFinished: Long) {
                val hours = TimeUnit.MILLISECONDS.toHours(millisUntilFinished)
                val minutes =
                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) % TimeUnit.HOURS.toMinutes(
                        1
                    )
                val seconds =
                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) % TimeUnit.MINUTES.toSeconds(
                        1
                    )

                // Format waktu ke dalam string
                val timeString = String.format("%02d:%02d:%02d", hours, minutes, seconds)

                // Set text pada TextView
                timerTextView.text = timeString
            }

            override fun onFinish() {
                // Aksi yang akan diambil saat hitung mundur selesai (opsional)
                timerTextView.text = "Waktu Habis"
            }
        }

        // Mulai hitung mundur
        countDownTimer.start()
    }

    private fun generateRandomCode(length: Int): String {
        val random = Random()
        val charPool: List<Char> = ('0'..'9') + ('A'..'Z')
        return (1..length)
            .map { random.nextInt(charPool.size) }
            .map(charPool::get)
            .joinToString("")
    }

    override fun onDestroy() {
        super.onDestroy()
        // Hentikan hitung mundur jika aktivitas dihancurkan
        countDownTimer.cancel()
    }
}
