package com.axter.kelompok_6_x

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Random
import java.util.concurrent.TimeUnit

class BerhasilBayarActivity : AppCompatActivity() {

    private lateinit var countDownTimer: CountDownTimer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.berhasil_bayar)

        val berhasilButton: Button = findViewById(R.id.selesai_bayar)

        // Tambahkan listener untuk menangani klik tombol "Bayar"
        berhasilButton.setOnClickListener(View.OnClickListener {
            // Buat Intent untuk membuka aktivitas pembayaran
            val intent = Intent(this, MainActivity::class.java)

            // Mulai aktivitas pembayaran
            startActivity(intent)
        })
    }
}