package com.axter.kelompok_6_x

import android.os.Bundle
import android.view.View
import android.content.Intent
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Variabel untuk menyimpan jumlah produk dan harga per produk
    private var jumlahProduk: Int = 0
    private var hargaPerProduk: Int = 0
    private var totalHarga: Int = 0
    private var namaProduk: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Dapatkan referensi ke RadioGroup dan TextView harga
        val radioGroup: RadioGroup = findViewById(R.id.radioGroup)
        val hargaTextView: TextView = findViewById(R.id.harga)
        val jumlahProdukTextView: TextView = findViewById(R.id.jlhProduk)
        val totalHargaTextView: TextView = findViewById(R.id.totalHarga)

        // Dapatkan referensi ke Button tambah dan kurang
        val tambahButton: Button = findViewById(R.id.btnTambah)
        val kurangButton: Button = findViewById(R.id.btnKurang)

        // Tambahkan listener untuk menangani peristiwa perubahan pada RadioGroup
        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            // Handle the checked state change
            hargaPerProduk = when (checkedId) {
                R.id.list1 -> {
                    showToast("KERUPUK JANGEK selected")
                    namaProduk = "KERUPUK JANGEK"
                    12000 // Harga untuk KERUPUK JANGEK
                }
                R.id.list2 -> {
                    showToast("KEMPLANG PANGGANG BANGKA selected")
                    namaProduk = "KEMPLANG PANGGANG BANGKA"
                    22000 // Harga untuk KEMPLANG PANGGANG BANGKA
                }
                R.id.list3 -> {
                    showToast("KEMPLANG SUPER TIPIS selected")
                    namaProduk = "KEMPLANG SUPER TIPIS"
                    17000 // Harga untuk KEMPLANG SUPER TIPIS
                }
                R.id.list4 -> {
                    showToast("KEMPLANG KULIT PESER SUPER selected")
                    namaProduk = "KEMPLANG KULIT PESER SUPER"
                    14000 // Harga untuk KEMPLANG KULIT PESER SUPER
                }
                R.id.list5 -> {
                    showToast("KEMPLANG SUPER MAWAR selected")
                    namaProduk = "KEMPLANG SUPER MAWAR"
                    13000 // Harga untuk KEMPLANG SUPER MAWAR
                }
                else -> {
                    showToast("No product selected")
                    namaProduk = "TIDAK ADA YANG ANDA PILIH"
                    0 // Harga default jika tidak ada produk yang dipilih
                }
            }

            // Tampilkan harga produk pada TextView
            hargaTextView.text = "Rp ${hargaPerProduk}"
            // Update total harga berdasarkan jumlah produk
            updateTotalHarga()
        }

        // Tambahkan listener untuk tombol tambah
        tambahButton.setOnClickListener {
            tambahProduk()
            // Update total harga berdasarkan jumlah produk
            updateTotalHarga()
        }

        // Tambahkan listener untuk tombol kurang
        kurangButton.setOnClickListener {
            kurangiProduk()
            // Update total harga berdasarkan jumlah produk
            updateTotalHarga()
        }
        // Dapatkan referensi ke tombol "Bayar"
        val bayarButton: Button = findViewById(R.id.bayar)

        // Tambahkan listener untuk menangani klik tombol "Bayar"
        bayarButton.setOnClickListener(View.OnClickListener {
            // Buat Intent untuk membuka aktivitas pembayaran
            val intent = Intent(this, PembayaranActivity::class.java)

            intent.putExtra("EXTRA_JUMLAH_PRODUK", jumlahProduk)
            intent.putExtra("EXTRA_TOTAL_HARGA", totalHarga)
            intent.putExtra("EXTRA_NAMA_PRODUK", namaProduk)

            // Mulai aktivitas pembayaran
            startActivity(intent)
        })
    }

    // Fungsi untuk menampilkan pesan Toast
    private fun showToast(message: String) {
        // Tambahkan logika sesuai kebutuhan
    }

    // Fungsi untuk menambah jumlah produk
    private fun tambahProduk() {
        jumlahProduk++
        updateJumlahProdukTextView()
    }

    // Fungsi untuk mengurangi jumlah produk
    private fun kurangiProduk() {
        if (jumlahProduk > 0) {
            jumlahProduk--
            updateJumlahProdukTextView()
        }
    }

    // Fungsi untuk memperbarui TextView jumlah produk
    private fun updateJumlahProdukTextView() {
        val jumlahProdukTextView: TextView = findViewById(R.id.jlhProduk)
        jumlahProdukTextView.text = jumlahProduk.toString()
    }

    // Fungsi untuk memperbarui total harga
    private fun updateTotalHarga() {
        totalHarga = jumlahProduk * hargaPerProduk
        val totalHargaTextView: TextView = findViewById(R.id.totalHarga)
        totalHargaTextView.text = "Rp ${totalHarga}"
    }

}
