package com.axter.kelompok_6_x

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu

class PembayaranActivity : AppCompatActivity() {

    private var totalHarga: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pembayaran)

        // Dapatkan jumlah produk dari intent
        val jumlahProduk: Int = intent.getIntExtra("EXTRA_JUMLAH_PRODUK", 0)
        totalHarga = intent.getIntExtra("EXTRA_TOTAL_HARGA", 0)
        val namaProduk = intent.getStringExtra("EXTRA_NAMA_PRODUK")

        // Lakukan sesuatu dengan jumlah produk, misalnya set text pada TextView
        val rincianProduk: TextView = findViewById(R.id.rincianProduk)
        rincianProduk.text = "$namaProduk"

        val rincianJumlah: TextView = findViewById(R.id.rincianJumlah)
        rincianJumlah.text = "x$jumlahProduk"

        val rincianHarga: TextView = findViewById(R.id.rincianHarga)
        rincianHarga.text = "Rp.$totalHarga"



        val btnMetodePembayaran: Button = findViewById(R.id.metodePembayaran)
        btnMetodePembayaran.setOnClickListener { showPopupMenu(btnMetodePembayaran) }

        // Dapatkan referensi ke tombol "Bayar"
        val kembaliButton: Button = findViewById(R.id.kembali)

        // Tambahkan listener untuk menangani klik tombol "Bayar"
        kembaliButton.setOnClickListener(View.OnClickListener {
            // Buat Intent untuk membuka aktivitas pembayaran
            val intent = Intent(this, MainActivity::class.java)

            // Mulai aktivitas pembayaran
            startActivity(intent)
        })

        val bayarButton: Button = findViewById(R.id.bayar)

        // Tambahkan listener untuk menangani klik tombol "Bayar"
        bayarButton.setOnClickListener(View.OnClickListener {
            // Buat Intent untuk membuka aktivitas pembayaran
            val intent = Intent(this, ProsesPembayaran::class.java)

            intent.putExtra("EXTRA_TOTAL_HARGA", totalHarga)

            // Mulai aktivitas pembayaran
            startActivity(intent)
        })
    }

    private fun showPopupMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.menu_metode_pembayaran, popupMenu.menu)

        // Set listener untuk menangani item yang dipilih
        popupMenu.setOnMenuItemClickListener { item: MenuItem ->
            when (item.itemId) {
                R.id.sumsel -> {
                    // Lakukan sesuatu saat metode pembayaran pertama dipilih
                    true
                }
                R.id.bri -> {
                    // Lakukan sesuatu saat metode pembayaran kedua dipilih
                    true
                }
                R.id.dana -> {
                    // Lakukan sesuatu saat metode pembayaran kedua dipilih
                    true
                }
                R.id.cod -> {
                    // Lakukan sesuatu saat metode pembayaran kedua dipilih
                    true
                }
                // Tambahkan opsi lain jika diperlukan
                else -> false
            }
        }

        popupMenu.show()
    }


}
